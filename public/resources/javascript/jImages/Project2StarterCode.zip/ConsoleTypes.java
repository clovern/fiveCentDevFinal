package project2GIVE_TO_STUDENTS;

public enum ConsoleTypes
{   NoSelection,
    PlayStation4,
    XBoxOneS,
    PlayStation4Pro,
    NintendoSwich,
    SegaGenesisMini; // Best retro
}
